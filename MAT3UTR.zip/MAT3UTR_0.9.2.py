import math
import numpy as np
import os,glob
import scipy.stats as stats
from scipy.stats.stats import pearsonr
from scipy.stats import spearmanr
import itertools
import sys

#test command
#python MAT3UTR_0.9.2.py -a ../data/refGene_hg19.txt -b CFII25ExprNormal.txt -c CFII25ExprNormal.txt -d DE_CFII25.txt -e ../pythons_CFIm25newMiRs/outSigMiROverlapBWTxs.txt -f ../data/RNASeq_CFII25/nature13261-s1.txt -g ../data/targetScan/miR_Family_Info.txt -i miRSitesbyTx.txt -j ../pythons_CFIm25/MiRExpByGenes.txt -o transEffectParamOpt_CFIm25.txt
from optparse import OptionParser
usage = "usage: %prog -a arg1 -b arg2 -c arg3 -d arg4 -e arg5 -f arg6 -g arg7 -i arg8 -j arg9 -o arg10"
parser = OptionParser()
parser.add_option("-a", "--geneModel", dest="geneModel", help="file with gene models", metavar="FILE")
parser.add_option("-b", "--geneExprNormal", dest="geneExprNormal", help="file with gene expression", metavar="FILE")
parser.add_option("-c", "--geneExprTumor", dest="geneExprTumor", help="file with gene expression", metavar="FILE")
parser.add_option("-d", "--geneDE", dest="geneDE", help="file with differential expression status", metavar="FILE")

parser.add_option("-e", "--ceRNA", dest="ceRNA", help="file with ceRNA crosstalk informatoin", metavar="FILE")
parser.add_option("-f", "--3'UTR shortening", dest="threeUS", help="file with 3UTR shortening information", metavar="FILE")

parser.add_option("-g", "--miRNAFam", dest="miRNAFam", help="file with miRNA family information", metavar="FILE")
parser.add_option("-i", "--miRNASite", dest="miRNASite", help="file with miRNA binding site information", metavar="FILE")
parser.add_option("-j", "--miRNAExpr", dest="miRNAExpr", help="file with miRNA expression", metavar="FILE")

parser.add_option("-o", "--matFile", dest="matFile", help="matrix file for model fitting", metavar="FILE")
(options, args) = parser.parse_args()
geneModel=options.geneModel
geneExprNormal=options.geneExprNormal
geneExprTumor=options.geneExprTumor
geneDE=options.geneDE
ceRNA=options.ceRNA
threeUS=options.threeUS
miRNAFam=options.miRNAFam
miRNASite=options.miRNASite
miRNAExpr=options.miRNAExpr
matFile=options.matFile

geneFoldChange={}
ups,dns,nos=[],[],[]
diffRsltFile=open(geneDE, "r")
header=diffRsltFile.readline()
for aLine in diffRsltFile:
    fields=aLine.rstrip("\n").split("\t")
    geneName,logFC,FDR=fields[0],float(fields[1]),float(fields[2])
    geneFoldChange[geneName]=logFC
    if FDR<0.05:
        if logFC>0:
            ups.append(geneName)
        elif logFC<0:
            dns.append(geneName)
        else:
            print 'gene DE file out of format'
    else:
        nos.append(geneName)
ups,dns,nos=set(ups),set(dns),set(nos)
nos=nos-ups-dns
ups=ups-dns
dns=dns-ups


#it returns overlap (+int, overlapStart, overlapEnd) or dist (-int, None, None)
def getOverlapOrDist(a, b):
    overlapOrDist=min(a[1], b[1]) - max(a[0], b[0])
    if overlapOrDist<0:
        return (overlapOrDist, None, None)
    else:
        return (overlapOrDist, max(a[0], b[0]), min(a[1], b[1]))

tx2gene={}
refAnnots={}
refSeqInfos,txsByGene,txsByGene={},{},{}
refSeqInfoFile=open(geneModel, "r")
header=refSeqInfoFile.readline()
for aRefSeqInfo in refSeqInfoFile:
    fields=aRefSeqInfo.rstrip("\n").split("\t")
    txName,chrID,strand,txStart,txEnd,cdsStart,cdsEnd,NCBIID=[fields[i] for i in [1,2,3,4,5,6,7,12]]
    txName=txName.upper()
    NCBIID=NCBIID.upper()

    tx2gene[txName]=NCBIID
    refAnnots[NCBIID]=([],[])
    if txName not in refSeqInfos:
        refSeqInfos[txName]=[(NCBIID, chrID,strand,int(txStart),int(txEnd),int(cdsStart),int(cdsEnd))]
    else:
        refSeqInfos[txName].append((NCBIID, chrID,strand,int(txStart),int(txEnd),int(cdsStart),int(cdsEnd)))
    if NCBIID not in txsByGene:
        txsByGene[NCBIID]=[]
    if txName not in txsByGene[NCBIID]:
        txsByGene[NCBIID].append(txName)
refSeqInfoFile.close()

caseNum=0
sigAPAGenes=[]
sigCommonAPA={}
sigAPAGenesFile=open(threeUS, "r")
header=sigAPAGenesFile.readline()
for aLine in sigAPAGenesFile:
    fields=aLine.rstrip("\n").split("\t")
    sigCommonAPA[fields[0]]=(float(fields[1]), float(fields[2]), float(fields[3]))#pUTR,TumorPDUI,NormalPDUI
    sigAPAGenes.append(refSeqInfos[fields[0]][0][0])
sigAPAGenesFile.close()

CDSExprsNormal={}
CDSExprsTumor={}
sampleFileNormal=open(geneExprNormal, "r")
CDSExprsTumor,CDSExprsNormal={},{}
for aLine in sampleFileNormal:
    fields=aLine.rstrip("\n").split("\t")
    if fields[0].startswith("?"):
        continue
    CDSExprsNormal[fields[0].upper()]=[float(i) for i in fields[1:]]
sampleFileNormal.close()
sampleFileTumor=open(geneExprTumor, "r")
for aLine in sampleFileTumor:
    fields=aLine.rstrip("\n").split("\t")
    if fields[0].startswith("?"):
        continue
    CDSExprsTumor[fields[0].upper()]=[float(i) for i in fields[1:]]
sampleFileTumor.close()
expresseds=set(CDSExprsNormal.keys())&set(CDSExprsTumor.keys())

ceRNAPartnersAPA={}#key: an APA ceRNA, value: its APA gene partners
APAceRNAPartners={}#Key: APA gene, values: all its ceRNA partners
ceRNAFile=open(ceRNA, "r")
for aLine in ceRNAFile:
    cePartner,APAGenesStr=aLine.rstrip("\n").split("\t")
    APAGenes=APAGenesStr.split(",")
    ceRNAPartnersAPA[cePartner]=APAGenes
    for APAGene in APAGenes:
        if APAGene not in APAceRNAPartners:
            APAceRNAPartners[APAGene]=[]
        APAceRNAPartners[APAGene].append(cePartner)
ceRNAFile.close()

genesByMiR={}
miRSitesbyTx={}#holding miR binding sites in each gene's 3UTR. 
miRSitesbyTxFile=open(miRNASite, "r")
for aLine in miRSitesbyTxFile:
    tx,gene,miRFamID,chrID,start,end,strand=aLine.rstrip("\n").split("\t")
    if miRFamID not in genesByMiR:
        genesByMiR[miRFamID]=[]
    genesByMiR[miRFamID].append(gene)
    
    if tx not in miRSitesbyTx:
        miRSitesbyTx[tx]=[]
    miRSitesbyTx[tx].append((gene,miRFamID,chrID,int(start),int(end),strand))
miRSitesbyTxFile.close()

import os.path
import glob
import numpy as np
TomiRFam={}
miRInfoFile=open(miRNAFam, "r")
header=miRInfoFile.readline()
for anMiR in miRInfoFile:
    fields=anMiR.rstrip("\n").split("\t")
    miRFam,speciesID,miRBaseID=[fields[i] for i in [0,2,3]]
    #assert speciesID=="9606", "this should be about HG19 (9606)"
    TomiRFam[miRBaseID]=miRFam.lower()
miRInfoFile.close()

miRsNotHighLow={}
miRExpByGenes={}
fileMiRExpByGenes=open(miRNAExpr, "r")
for aLine in fileMiRExpByGenes:
    famID,valCtrl,valCFII25=aLine.rstrip("\n").split("\t")
    miRsNotHighLow[famID]=(float(valCtrl),float(valCFII25))
    valSum=float(valCtrl)+float(valCFII25)
fileMiRExpByGenes.close()
miRsNotHighLowKeys=miRsNotHighLow.keys()

#assert x in sigCommonAPAWpUTR
def miRsPDUI(x, miRj, normOrTumor):#average # miRj binding sites per each trancript of x
    minPDUI,minTumorPDUI,minNormalPDUI=1,-2,-2
    assert len(set(txsByGene[x])&set(sigCommonAPA.keys()))>0, "It should undergo 3UTR shortening"#the case of 3UTR shortening gene
    maxNumMiRs=0
    numMiRsAcross=None
    for tx in txsByGene[x]:
        if tx not in sigCommonAPA:
            continue
        if tx.startswith("NR"):
            continue
        if tx not in refSeqInfos:
            continue
        if len(sigCommonAPA[tx])==0:
            continue
        strandAll=refSeqInfos[tx][0][2]
        threeUTR_Start,threeUTR_End=0,0
        if strandAll=='+':
            threeUTR_Start=refSeqInfos[tx][0][6]
            threeUTR_End=refSeqInfos[tx][0][4]
        else:# minus strand
            threeUTR_Start=refSeqInfos[tx][0][3]
            threeUTR_End=refSeqInfos[tx][0][5]

        pUTR,tumorPDUI,normalPDUI=sigCommonAPA[tx]
        if (tumorPDUI-normalPDUI)<minPDUI:
            minPDUI=tumorPDUI-normalPDUI
            minTumorPDUI=tumorPDUI
            minNormalPDUI=normalPDUI

            if pUTR>threeUTR_End:
                pUTR=threeUTR_End
            elif pUTR<threeUTR_Start:
                pUTR=threeUTR_Start
            assert (pUTR-threeUTR_Start)*(pUTR-threeUTR_End)<=0, 'pUTR must be between threeUTR_Start and threeUTR_End'

            numMiRs_pUTR,numMiRs_dUTR=0,0
            for geneID,miRFamID,chrID,seedStart,seedEnd,strand in miRSitesbyTx[tx]:
                if miRj==miRFamID:
                    if strandAll=="+":
                        if getOverlapOrDist((pUTR,threeUTR_End), (seedStart,seedEnd))[0]>0:#when it is on a boundary, it is dUTR
                            numMiRs_dUTR+=1
                        elif getOverlapOrDist((threeUTR_Start,pUTR), (seedStart,seedEnd))[0]>0:
                            numMiRs_pUTR+=1
                    elif strandAll=="-":
                        if getOverlapOrDist((threeUTR_Start,pUTR), (seedStart,seedEnd))[0]>0:#if it's in dUTR, because of the negagive strand
                            numMiRs_dUTR+=1
                        elif getOverlapOrDist((pUTR,threeUTR_End), (seedStart,seedEnd))[0]>0:
                            numMiRs_pUTR+=1
            if maxNumMiRs<=numMiRs_pUTR+numMiRs_dUTR:
                maxNumMiRs=numMiRs_pUTR+numMiRs_dUTR
                numMiRsAcross=(numMiRs_pUTR,numMiRs_dUTR)
        assert numMiRsAcross!=None, 'there should be a tx:'+x
        assert ((minTumorPDUI!=-2) and (minNormalPDUI!=-2)), 'PDUI values must be assigned'

    if normOrTumor==0:#normal
        return numMiRsAcross[0]+numMiRsAcross[1]*minNormalPDUI
    else:
        return numMiRsAcross[0]+numMiRsAcross[1]*minTumorPDUI
    #return numMiRsAcross[0]+numMiRsAcross[1]*minNormalPDUI#Just as Wei's control

def miRs(x, miRj, normOrTumor):#average # miRj binding sites per each trancript of x
    maxNumMiRs=0
    for tx in txsByGene[x]:
        if tx.startswith("NR"):
            continue
        if tx not in refSeqInfos:
            continue
        if tx not in miRSitesbyTx:
            continue
        numMiRs=len([i for i in miRSitesbyTx[tx] if miRj==i[1]])
        if maxNumMiRs<=numMiRs:
            maxNumMiRs=numMiRs
    assert maxNumMiRs!=0, 'there should be a tx:'+x
    return maxNumMiRs

#normOrTumor: 0 if normal, 1 if tumor
def totMiRs(m, miRj, normOrTumor):#total # miRj binding sites in x
    RPKMInSample=[]
    if normOrTumor==0:
        RPKMInSample=np.array(CDSExprsNormal[m])
    elif normOrTumor==1:
        RPKMInSample=np.array(CDSExprsTumor[m])
    if m in sigAPAGenes:
        return miRsPDUI(m, miRj, normOrTumor)*RPKMInSample.mean()
    else:
        return miRs(m, miRj, normOrTumor)*RPKMInSample.mean()

def transE(miRj, y, normOrTumor):
    denum1=.0
    APAGenes=ceRNAPartnersAPA[y]
    ceRNAPartners=[]
    for APAGene in APAGenes:
        continueFlag=False
        for tx in txsByGene[APAGene]:
            if tx not in sigCommonAPA:
                continue
            if tx not in miRSitesbyTx:
                continue
            if tx.startswith("NR"):
                continue
            continueFlag=True
        if continueFlag==False:
            continue

        if APAGene not in APAceRNAPartners:
            continue
        if miRj not in set(sum([[i[1] for i in miRSitesbyTx[tx]] for tx in txsByGene[APAGene] if tx in miRSitesbyTx], [])):
            continue
        denum1+=totMiRs(APAGene, miRj, normOrTumor)
        ceRNAPartners+=APAceRNAPartners[APAGene]
    denum1*=1
    denum2=.0
    ceRNAPartners=set(ceRNAPartners)
    for ceRNAPartner in ceRNAPartners:
        #if ceRNAPartner==y:
        #    continue
        if miRj not in set(sum([[i[1] for i in miRSitesbyTx[tx]] for tx in txsByGene[ceRNAPartner] if tx in miRSitesbyTx], [])):
            continue
        denum2+=totMiRs(ceRNAPartner, miRj, normOrTumor)
    #num=totMiRs(y, miRj, normOrTumor)*miRsNotHighLow[miRj][normOrTumor]
    denum2*=1
    return denum1+denum2

def dnTransE(y):
    miREffects1,miREffects2={},{}
    miRs4y=set(sum([[i[1] for i in miRSitesbyTx[tx]] for tx in txsByGene[y] if tx in miRSitesbyTx], []))&set(miRsNotHighLow.keys())
    transEs=.0
    for miRj in miRs4y:
        totMiRsT=transE(miRj, y, 1)
        if totMiRsT==0:
            continue
        totMiRsN=transE(miRj, y, 0)
        if totMiRsN==0:
            continue
        miREffects1[miRj]=math.log((miRsNotHighLow[miRj][1]+0.0001)/(miRsNotHighLow[miRj][0]+0.0001))#it's tumor/normal
        miREffects2[miRj]=math.log(totMiRsN/totMiRsT)#it's normal/tumor, because it works reciprocal.
    return miREffects1,miREffects2

transPDUI_dnEffect=[]
outFile=open(matFile, "w")
outFile.write("APA ceRNA partner\t"+"\t".join(miRsNotHighLowKeys)+"\t"+"\t".join(miRsNotHighLowKeys)+"\tresponse\n")
for APAceRNAPartner in ceRNAPartnersAPA:
    if APAceRNAPartner not in geneFoldChange:
        continue
    resultLine=APAceRNAPartner+"\t"
    miREffects1,miREffects2=dnTransE(APAceRNAPartner)
    relevantMiRs=miREffects1.keys()
    
    for miRNotHighLowKeys in miRsNotHighLowKeys:
        if miRNotHighLowKeys in miREffects1:
            resultLine+=str(miREffects1[miRNotHighLowKeys])+"\t"
        else:
            resultLine+="0\t"
    for miRNotHighLowKeys in miRsNotHighLowKeys:
        if miRNotHighLowKeys in miREffects2:
            resultLine+=str(miREffects2[miRNotHighLowKeys])+"\t"
        else:
            resultLine+="0\t"
    resultLine+=str(geneFoldChange[APAceRNAPartner])+"\n"#+",".join(set(ceRNAPartnersAPA[APAceRNAPartner]))+"\n"
    outFile.write(resultLine)
outFile.close()        
