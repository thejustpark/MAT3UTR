MATin="MAT_TCGA.txt"
MATout="MAT3UTR_TCGA.txt"
df=read.delim(MATin)[,-1]
x=df[,-ncol(df)]
y=df[,ncol(df)]
n=nrow(x)
p=ncol(x)

library(glmnet)
set.seed(1234)
x <- apply(x, 2, as.double)
cv.fit <- cv.glmnet(x, y, type.measure="mse", alpha=0)
pred <- predict(cv.fit,newx=x, s="lambda.min")
fitted.values <- pred[,1]
R_squared=cor(y, fitted.values)**2 
corVal=cor(y, fitted.values) 
print(paste("In MAT3UTR, Rsquared is ",R_squared, ", Correlation is ", corVal ,sep=""))
result = data.frame(gene=read.delim(MATin)[,1],resonse=y,fitted.values= fitted.values)
write.table(result, file = MATout, append = FALSE, sep = "\t")

df_cont=df[,c(1:c(p/2),ncol(df))]
x_cont=df_cont[,-ncol(df_cont)]
y_cont=df_cont[,ncol(df_cont)]
x_cont <- apply(x_cont, 2, as.double)
set.seed(1234)
cv.fit_cont <- cv.glmnet(x_cont, y, type.measure="mse", alpha=0)
pred_cont <- predict(cv.fit_cont,newx=x_cont, s="lambda.min")
fitted.values_cont <- pred_cont[,1]
R_squared_cont=cor(y_cont, fitted.values_cont)**2  
corrVal_cont=cor(y_cont, fitted.values_cont) 
print(paste("In MAT3UTR_Control, Rsquared is ",R_squared_cont, ", Correlation is ", corrVal_cont ,sep=""))
